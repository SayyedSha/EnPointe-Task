// import logo from './logo.svg';
import './App.css';
import Layout from './components/Layout';
import Login from './components/LoginPage';
import UserPage from './components/UserPage';
// import Navbar from './components/Navbar';
import {Routes, Route, BrowserRouter} from "react-router-dom"
import Dashboard from './components/dashboard';
import Transaction from './components/Transaction';

function App() {
  return (
    
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login/>}/>
          <Route element={<Layout/>}>
              <Route path="user" element={<UserPage />}/>
              <Route path="dashboard" element={<Dashboard />}/>
              <Route path="transaction" element={<Transaction />}/>
              {/* <Route path="dashboard" element={<Dashboard />}/> */}
            
          </Route>
        </Routes>
      </BrowserRouter>
    </>
   
  );
}

export default App;
