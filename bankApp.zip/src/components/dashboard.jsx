// import axios from 'axios';
// import React, { useEffect } from 'react';
// import Chart from 'react-apexcharts';

// const data = {
    
//     series: [
//         {
//             name: "UV",
//             data: [4000, 3000, 2000, 2780, 1890, 2390, 3490]
//         },
//         {
//             name: "PV",
//             data: [2400, 1398, 9800, 3908, 4800, 3800, 4300]
//         }
//     ],
//     options: {
//         chart: {
//             height: 350,
//             type: 'line',
//             zoom: {
//                 enabled: false
//             }
//         },
//         dataLabels: {
//             enabled: false
//         },
//         stroke: {
//             curve: 'smooth'
//         },
//         title: {
//             text: 'Monthly Data',
//             align: 'left'
//         },
//         grid: {
//             row: {
//                 colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
//                 opacity: 0.5
//             },
//         },
//         xaxis: {
//             categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
//         }
//     }
// };

// function Dashboard() {
//     useEffect(() => {
//         const fetchUsers = async () => {
//           try {
//             // console.log(localStorage.User)
//             const kpiresponse = await axios.get("http://localhost:8001/api/dashboard/KPI",{headers:{
//                 Authorization:`Bearer ${localStorage.User}`
//               }});
//             console.log(kpiresponse.data)
//             const graphresponse = await axios.get("http://localhost:8001/api/dashboard/graph",{headers:{
//                 Authorization:`Bearer ${localStorage.User}`
//               }});
//               console.log(graphresponse.data)
//           } catch (error) {
//             console.error("Error fetching users:", error);
//           }
//         };
    
//         fetchUsers();
//       }, []);
//     return (
//         <div style={{ padding: '20px' }}>
//             <h1>Dashboard</h1>
//             <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '20px' }}>
//                 <div style={{ textAlign: 'center' }}>
//                     <h2>KPI 1</h2>
//                     <p>Value: 123</p>
//                 </div>
//                 <div style={{ textAlign: 'center' }}>
//                     <h2>KPI 2</h2>
//                     <p>Value: 456</p>
//                 </div>
//                 <div style={{ textAlign: 'center' }}>
//                     <h2>KPI 3</h2>
//                     <p>Value: 789</p>
//                 </div>
//             </div>
//             <div>
//                 <Chart 
//                     options={data.options} 
//                     series={data.series} 
//                     type="line" 
//                     height={350} 
//                 />
//             </div>
//         </div>
//     );
// }

// export default Dashboard;


import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Chart from 'react-apexcharts';
import Select from 'react-select';
import './Dashboard.css';

function Dashboard() {
    const [kpiData, setKpiData] = useState({ totalDebited: 0, totalCredited: 0, currentBalance: 0 });
    const [graphData, setGraphData] = useState([]);
    const [selectedYear, setSelectedYear] = useState("2023");
    const [years, setYears] = useState([]);

    useEffect(() => {
        const fetchKpiData = async () => {
            try {
                const response = await axios.get("http://localhost:8001/api/dashboard/KPI", {
                    headers: {
                        Authorization: `Bearer ${localStorage.User}`
                    }
                });
                setKpiData(response.data);
            } catch (error) {
                console.error("Error fetching KPI data:", error);
            }
        };

        const fetchGraphData = async (year) => {

            try {
                const response = await axios.get(`http://localhost:8001/api/dashboard/graph?year=2023`, {
                    headers: {
                        Authorization: `Bearer ${localStorage.User}`
                    }
                })
                console.log(response)
                setGraphData(response.data.graph);
                setYears([...new Set(response.data.graph.map(item => item.year))]);
            } catch (error) {
                console.error("Error fetching graph data:", error);
            }
        };

        fetchKpiData();
        fetchGraphData(selectedYear);
    }, [selectedYear]);

    const handleYearChange = (selectedOption) => {
        setSelectedYear(selectedOption.value);
    };

    const graphOptions = {
        series: [
            {
                name: "Total Credited Amount",
                data: graphData.map(data => data.totalCreditedAmount)
            },
            {
                name: "Total Debited Amount",
                data: graphData.map(data => data.totalDebitedAmount)
            }
        ],
        options: {
            chart: {
                height: 350,
                type: 'line',
                zoom: {
                    enabled: false
                }
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth'
            },
            title: {
                text: 'Monthly Data',
                align: 'left'
            },
            grid: {
                row: {
                    colors: ['#f3f3f3', 'transparent'],
                    opacity: 0.5
                },
            },
            xaxis: {
                categories: graphData.map(data => data.monthName),
            }
        }
    };

    const yearOptions = years.map(year => ({ value: year, label: year }));

    return (
        <div className="container">
            <h1 className="title">Dashboard</h1>
            <div className="kpi-container">
                <div className="kpi">
                    <h2>Total Credited</h2>
                    <p>{kpiData.totalCredited}</p>
                </div>
                <div className="kpi">
                    <h2>Total Debited</h2>
                    <p>{kpiData.totalDebited}</p>
                </div>
                <div className="kpi">
                    <h2>Current Balance</h2>
                    <p>{kpiData.currentBalance}</p>
                </div>
            </div>
            <div className="graph-container">
                <div className="year-select">
                    <Select
                        value={{ value: selectedYear, label: selectedYear }}
                        onChange={handleYearChange}
                        options={yearOptions}
                    />
                </div>
                <Chart
                    options={graphOptions.options}
                    series={graphOptions.series}
                    type="line"
                    height={350}
                />
            </div>
        </div>
    );
}

export default Dashboard;
