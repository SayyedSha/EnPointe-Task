import axios from "axios";
import React, { useRef} from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const Email = useRef(null);
  const Password = useRef(null);
  const navigate = useNavigate()


  const handleLogin = async() => {
    try{
        console.log(Password.current.value)
        const response = await axios.post("http://localhost:8001/api/user/login",{
            email: Email.current.value,
            password: Password.current.value
        },{headers:{apikey:"hiGGsboSon",secretkey:"kepLer32c"}})
        console.log(response)
        if (response.data.user){
            localStorage.setItem("User",response.data.accessToken)
            navigate('/dashboard')
        }else {
            console.log(response.data.error)
            if (response.data.error){
                alert(response.data.error)
            }else{
                alert("Something Went Wrong Please try again")
            }   
        }
    }
    catch(error){
        // alert(error)
        console.log(error)
    }
  };

  return (
    <div className="flex min-h-full flex-col justify-center px-6 py-12 lg:px-8">
  <div className="sm:mx-auto sm:w-full sm:max-w-sm">
    {/* <img class="mx-auto h-10 w-auto" src="" alt="Your Company"/> */}
    <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">Sign in to your account</h2>
  </div>

  <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
    {/* <form class="space-y-6" action="#" method="POST"> */}
      <div>
        <label htmlFor="email" className="block text-sm font-medium leading-6 text-gray-900">Email address</label>
        <div className="mt-2">
          <input id="email" name="email" type="email" ref={Email} required className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"/>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between">
          <label htmlFor="password" className="block text-sm font-medium leading-6 text-gray-900">Password</label>
          {/* <div class="text-sm">
            <a href="#" class="font-semibold text-indigo-600 hover:text-indigo-500">Forgot password?</a>
          </div> */}
        </div>
        <div className="mt-2">
          <input id="password" name="password" type="password" ref={Password}  required className="block w-full rounded-md border-1 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"/>
        </div>
      </div>
          <br />
      <div>
        <button type="submit" className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600" onClick={handleLogin}>Sign in</button>
      </div>
    {/* </form> */}

    {/* <p class="mt-10 text-center text-sm text-gray-500">
      Not a member?
      <a href="#" class="font-semibold leading-6 text-indigo-600 hover:text-indigo-500">Start a 14 day free trial</a>
    </p> */}
  </div>
</div>
  );}