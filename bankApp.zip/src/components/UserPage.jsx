import React, { useState, useEffect } from 'react';
import axios from 'axios';
// import Navbar from './Navbar';

export default function UserPage() {
  
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        
        const response = await axios.get("http://localhost:8001/api/user/getAlluser",);
        setUsers(response.data.users); 
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsers();
  }, []);

  return (
    <>
    <table className="table-auto">
      <thead>
        <tr>
          <th>Full Name</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Phone</th>
        </tr>
      </thead>
      <tbody>
        {users.map((user) => (
          <tr key={user.id}>
            <td>{user.fullName}</td>
            <td>{user.email}</td>
            <td>{user.gender}</td>
            <td>{user.phone}</td>
          </tr>
        ))}
      </tbody>
    </table>
    </>
  );
}
